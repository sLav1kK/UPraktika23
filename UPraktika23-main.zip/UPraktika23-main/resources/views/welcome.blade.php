@extends('layouts.app')

@section('content')
    <div class="container">
        <H1>Добро пожаловать</H1>
    </div>
@endsection
