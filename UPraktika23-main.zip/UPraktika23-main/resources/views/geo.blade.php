@extends('layouts.app')

@section('content')
<section class="geo">
      <div class="container">
        <div class="row">
          <div class="t-c">
          <p class="p-20 sma-t">Где нас найти</p>
        </div>
          <div class="col-xl-6 col-md-12 col-12">
            <img src="img/map.jpg" alt="">
          </div>
          <div class="col-xl-6 col-md-12 col-12">
            <P class="f-20">Адрес: г.Омск, ул. Дмитриева д.40 к.1</P>
            <P class="f-20">Номер телефона: +7(3812)99-99-99</P>
            <P class="f-20">Почта email: copystar@mail.ru</P>
          </div>
        </div>
      </div>
    </section>
@endsection

